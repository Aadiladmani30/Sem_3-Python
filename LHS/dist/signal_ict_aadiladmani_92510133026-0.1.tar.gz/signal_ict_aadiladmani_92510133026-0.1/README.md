# signal_ICT_AadilAdmani_92510133026

This is a Python package for generating and manipulating signals, including unitary signals (step, impulse, ramp), trigonometric signals (sine, cosine, exponential), and basic operations like shifting, scaling, addition, and multiplication.

## Installation

To install the package, you can use `pip`:

```bash
pip install signal_ICT_AadilAdmani_92510133026
